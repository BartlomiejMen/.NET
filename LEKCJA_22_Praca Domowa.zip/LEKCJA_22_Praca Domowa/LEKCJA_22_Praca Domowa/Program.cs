﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace LEKCJA_22_Praca_Domowa
{
    class Program
    {
        static void Main(string[] args)
        {
            int luckyNumber = TheGame.YourLuckyNumber();
            WriteLine("Witaj użytkowniku podaj liczbę i spróbuj szczęścia!");
            TheGame.GetUserNumber(luckyNumber);
                
        }



        


    }
}

