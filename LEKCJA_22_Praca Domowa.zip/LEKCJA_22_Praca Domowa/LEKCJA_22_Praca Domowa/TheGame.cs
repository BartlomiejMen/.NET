﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace LEKCJA_22_Praca_Domowa
{
    static class TheGame
    {

     
            static public int YourLuckyNumber()
            {
                Random random = new Random();
                int luckyNumber = random.Next(1, 100);
                return luckyNumber;
            }

            static public void GetUserNumber(int yourLuckyNumber)
            {
            try
            {
                uint i = 1;
                uint number;
                do
                {

                    number = uint.Parse(ReadLine());

                    if (yourLuckyNumber == number)
                    {
                        Console.WriteLine($"Wygrałeś za {i} próbą, szukana liczba to {yourLuckyNumber} GRATULACJE!!!");
                    }
                    else
                    {
                        string message = (yourLuckyNumber > number) ? "Lizczba ktorą podałeś jest za mała." : "Lizczba ktorą podałeś jest za duża.";
                        WriteLine(message);
                    }

                    i++;

                } while (yourLuckyNumber != number);


            }
            catch (Exception e)
            {

                WriteLine(e.Message);
            }
              
            }




    }
}

