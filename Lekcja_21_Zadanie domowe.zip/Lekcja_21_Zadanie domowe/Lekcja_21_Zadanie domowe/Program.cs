﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_21_Zadanie_domowe
{
    class Program
    {
        
        static void Main(string[] args)
        {

            UserAge userAge = new UserAge();
            userAge.SetAnswer();

        }
    }
}
