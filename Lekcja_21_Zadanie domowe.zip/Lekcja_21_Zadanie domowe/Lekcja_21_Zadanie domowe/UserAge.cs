﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_21_Zadanie_domowe
{
    class UserAge
    {

        private string name;
        private string placeOfBirth;
        private int yearOfBirth;
        private int monthOfBirth;
        private int dayOfBirth;

        public UserAge()
        {
            try
            {
                Console.Write("Podaj swoje imię: ");
                name = Console.ReadLine();

                Console.Write("Podaj rok urodzenia: ");
                yearOfBirth = int.Parse(Console.ReadLine());

                Console.Write("Podaj miesiąc urodzenia : ");
                monthOfBirth = int.Parse(Console.ReadLine());

                Console.Write("Podaj dzień urodzenia: ");
                dayOfBirth = int.Parse(Console.ReadLine());

                Console.Write("Podaj miejsce urodzenia: ");
                placeOfBirth = Console.ReadLine();

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        private int CountsTheUserYears()
        {
           var currentYear = DateTime.Now.Year;
           var dayOfYearNow = DateTime.Now.DayOfYear;

           var userData = new DateTime(yearOfBirth, monthOfBirth, dayOfBirth);

                int userYears;

                 if (dayOfYearNow < (userData.DayOfYear+1))
                     {
                          userYears = currentYear - userData.Year -1;
                     }
                 else
                    {
                         userYears = currentYear - userData.Year;
                    }

         return userYears;
        }

        public void SetAnswer()
        {
            Console.WriteLine($"Cześć {name}, urodziłeś się w {placeOfBirth} i masz {CountsTheUserYears()} lat!");
        }


    }
        
}
